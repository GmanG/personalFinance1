package ua.home.model;

import java.util.List;

import javax.ejb.Local;

@Local
public interface BalanceEJBLocal {

//	List<Balance> getUserTransaction();
}
